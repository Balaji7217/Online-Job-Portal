# Online-Job-Portal-using-Java
The Online Job Search is a Java Dynamic Web Project created using JavaServer Pages, Servlets, and MySQL. 
The Online Job Search project is a comprehensive online job search platform that allows users to search for open jobs, create job postings, and manage job postings.
1. We have used JSP (JavaServer Pages), CSS & Bootstrap for frontend and backend with Java. 
2. We used servlet  for creating a web application which presents the user with a browser based interface.  
3. The backend database for the web application is MySQL and I have used MySQL workbench and MySQL query browser for managing the database. 
4. The web application is deployed in the tomcat server.
